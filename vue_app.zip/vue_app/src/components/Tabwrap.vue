<template>
	<div class="buttons-tab">
	   <slot></slot>
	</div>
</template>
<script>
	
</script>
<style scoped>
	.buttons-tab{
		top:2.2rem;
	}
</style>
